﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace GiftOfTheGivers_WebApp.Models
{
    public class User : IdentityUser
    {
        public string FullName { get; set; } = string.Empty;

        
 
    }
}
