﻿namespace GiftOfTheGivers_WebApp.Models
{
    public class DonationViewModel
    {
        public string Name { get; set; }  // Donor name
        public string Email { get; set; } // Donor email
        public string ResourceType { get; set; }
        public int Quantity { get; set; }
        public string Notes { get; set; }

        // Only for funds donations
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public string AccountHolder { get; set; }

        // New fields for Food/Clothes delivery
        public string DeliveryOption { get; set; } // "Self-Delivery" or "Volunteer Pickup"
        public string PickupAddress { get; set; } // Only if Volunteer Pickup
        public DateTime? PickupDate { get; set; } // Optional pickup scheduling
        public string PickupTime { get; set; }    // Optional pickup scheduling
    }
}
