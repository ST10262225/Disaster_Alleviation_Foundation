﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers_WebApp.Models
{
    public class Disaster
    {
        public int Id { get; set; }

        public int Title { get; set; }

        [Required]
        public string DisasterType { get; set; } // e.g. Flood, Fire, Storm

        [Required]
        public string Location { get; set; }

        [Required]
        public string Description { get; set; }

        public DateTime DateReported { get; set; }

        public string Status { get; set; }
    }
}
