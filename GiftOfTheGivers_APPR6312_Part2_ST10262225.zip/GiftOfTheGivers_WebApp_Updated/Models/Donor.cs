﻿namespace GiftOfTheGivers_WebApp.Models
{
    // In your Models/Donor.cs
    public class Donor
    {
        public int DonorID { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        // Navigation property
        public ICollection<Donation> Donations { get; set; }
    }
}
