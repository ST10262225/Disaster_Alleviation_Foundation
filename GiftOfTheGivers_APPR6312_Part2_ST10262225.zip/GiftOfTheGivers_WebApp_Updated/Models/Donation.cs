﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers_WebApp.Models
{
    public class Donation
    {
        [Key]
        public int DonationID { get; set; }

        [Required]
        public string ResourceType { get; set; }

        [Required]
        public int Quantity { get; set; }

        public string DonorID { get; set; }
        public User Donor { get; set; }

        public DateTime DateDonated { get; set; }
        public string Status { get; set; } = "Pending";
        public string Notes { get; set; }

        // Delivery info for Food/Clothes
        public string DeliveryOption { get; set; }
        public string PickupAddress { get; set; }
        public DateTime? PickupDate { get; set; }
        public string PickupTime { get; set; }
       

    }
}
