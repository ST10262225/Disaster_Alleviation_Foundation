﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfTheGivers_WebApp.Models
{
    public enum TaskStatus
    {
        Pending,
        InProgress,
        Completed
    }

    public class VolunteerTask
    {
        [Key]
        public int TaskID { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "Task name cannot exceed 100 characters.")]
        public string TaskName { get; set; }

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters.")]
        public string Description { get; set; }

        [ForeignKey("Volunteer")]
        public int VolunteerID { get; set; }

        public Volunteer Volunteer { get; set; }

        public TaskStatus Status { get; set; } = TaskStatus.Pending;

        public DateTime DateAssigned { get; set; } = DateTime.Now;
    }
}
