﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers_WebApp.Models
{
    public class Volunteer
    {
        [Key]
        public int VolunteerID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Phone { get; set; }

        [Required]
        public string Address { get; set; }

        public ICollection<VolunteerTask> Tasks { get; set; }

        [Required]
        public string Role { get; set; }
    }
}
