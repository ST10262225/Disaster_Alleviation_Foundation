﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers_WebApp.ViewModels
{
    public class AdminLoginViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public required string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public required string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }
}
