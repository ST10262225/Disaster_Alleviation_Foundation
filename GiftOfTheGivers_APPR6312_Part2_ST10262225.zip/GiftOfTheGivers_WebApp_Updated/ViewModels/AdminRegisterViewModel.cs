﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers_WebApp.ViewModels
{
    public class AdminRegisterViewModel
    {
        [Required, EmailAddress]
        public required string Email { get; set; }

        [Required, DataType(DataType.Password)]
        public required string Password { get; set; }

        [Required, DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Passwords do not match.")]
        public required string ConfirmPassword { get; set; }

        [Required]
        public required string SecretCode { get; set; }

        [Required]
        public required string FullName { get; set; } // required to match your DB not-null column
    }
}
