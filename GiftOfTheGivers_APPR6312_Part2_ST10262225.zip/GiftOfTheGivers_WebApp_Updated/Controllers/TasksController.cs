﻿using Microsoft.AspNetCore.Mvc;
using GiftOfTheGivers_WebApp.Data;
using DisasterAlleviationFoundation.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using GiftOfTheGivers_WebApp.Data;

namespace DisasterAlleviationFoundation.Controllers
{
    
    public class TasksController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TasksController(ApplicationDbContext context)
        {
            _context = context;
        }

        // INDEX: list all tasks
        public IActionResult Index()
        {
            var tasks = _context.TaskItems.ToList();
            return View(tasks);
        }

        // CREATE: form
       /* public IActionResult Create()
        {
            ViewBag.Volunteers = new SelectList(_context.VolunteerRegistrations.Where(v => v.IsApproved), "Id", "FullName");
            return View();
        } */

        [HttpPost]
       /* public IActionResult Create(TaskItem task)
        {
            if (ModelState.IsValid)
            {
                _context.TaskItems.Add(task);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Volunteers = new SelectList(_context.VolunteerRegistrations.Where(v => v.IsApproved), "Id", "FullName");
            return View(task);
        } */

        // EDIT: form
        /*public IActionResult Edit(int id)
        {
            var task = _context.TaskItems.Find(id);
            if (task == null) return NotFound();
            ViewBag.Volunteers = new SelectList(_context.VolunteerRegistrations.Where(v => v.IsApproved), "Id", "FullName");
            return View(task);
        }*/

        [HttpPost]
        /*public IActionResult Edit(TaskItem task)
        {
            if (ModelState.IsValid)
            {
                _context.TaskItems.Update(task);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Volunteers = new SelectList(_context.VolunteerRegistrations.Where(v => v.IsApproved), "Id", "FullName");
            return View(task);
        }*/

        // DELETE
        public IActionResult Delete(int id)
        {
            var task = _context.TaskItems.Find(id);
            if (task != null)
            {
                _context.TaskItems.Remove(task);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
