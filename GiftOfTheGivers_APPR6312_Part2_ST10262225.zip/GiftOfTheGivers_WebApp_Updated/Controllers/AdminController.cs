﻿using GiftOfTheGivers_WebApp.Data;
using GiftOfTheGivers_WebApp.Models;
using GiftOfTheGivers_WebApp.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GiftOfTheGivers_WebApp.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IConfiguration _configuration;

        public AdminController(ApplicationDbContext context,
                               UserManager<User> userManager,
                               SignInManager<User> signInManager,
                               RoleManager<IdentityRole> roleManager,
                               IConfiguration configuration)
        {
            _context = context;
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _configuration = configuration;
        }

        // -----------------------------
        // ADMIN REGISTRATION
        // -----------------------------
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Register() => View();

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(AdminRegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var adminSecretCode = _configuration["AdminSettings:SecretCode"];
            if (string.IsNullOrEmpty(adminSecretCode) || model.SecretCode != adminSecretCode)
            {
                ModelState.AddModelError("", "Invalid admin secret code.");
                return View(model);
            }

            var user = new User
            {
                FullName = model.FullName,
                UserName = model.Email,
                Email = model.Email
            };

            var result = await _userManager.CreateAsync(user, model.Password);
            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                    ModelState.AddModelError("", error.Description);
                return View(model);
            }

            if (!await _roleManager.RoleExistsAsync("Admin"))
                await _roleManager.CreateAsync(new IdentityRole("Admin"));

            await _userManager.AddToRoleAsync(user, "Admin");

            _context.Admins.Add(new Admin
            {
                UserId = user.Id,
                FullName = model.FullName
            });
            await _context.SaveChangesAsync();

            return RedirectToAction("Login", "Admin");
        }

        // -----------------------------
        // ADMIN LOGIN
        // -----------------------------
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login() => View();

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(AdminLoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null || !await _userManager.IsInRoleAsync(user, "Admin"))
            {
                ModelState.AddModelError("", "Invalid login attempt.");
                return View(model);
            }

            var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, false);
            if (result.Succeeded)
                return RedirectToAction("Dashboard", "Admin");

            ModelState.AddModelError("", "Invalid login attempt.");
            return View(model);
        }

        // -----------------------------
        // ADMIN LOGOUT
        // -----------------------------
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Login", "Admin");
        }

        // -----------------------------
        // DASHBOARD
        // -----------------------------
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Dashboard()
        {
            // Count only normal users (non-admins)
            var allUsers = await _userManager.Users.ToListAsync();
            int userCount = 0;
            foreach (var u in allUsers)
            {
                if (!await _userManager.IsInRoleAsync(u, "Admin"))
                    userCount++;
            }

            // Latest 5 donations (Donation objects)
            var latestDonations = _context.Donations
                                          .OrderByDescending(d => d.DateDonated)
                                          .Take(5)
                                          .ToList();

            ViewBag.Stats = new
            {
                Users = userCount,
                Incidents = _context.Disasters.Count(),
                DonationsCount = _context.Donations.Count(),
                Volunteers = _context.Volunteers.Count()
            };

            ViewBag.LatestDonations = latestDonations;

            return View();
        }

        // -----------------------------
        // USER MANAGEMENT
        // -----------------------------
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ManageUsers()
        {
            var normalUsers = new List<User>();
            var allUsers = await _userManager.Users.ToListAsync();
            foreach (var user in allUsers)
            {
                if (!await _userManager.IsInRoleAsync(user, "Admin"))
                    normalUsers.Add(user);
            }

            return View(normalUsers);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveUser(string id)
        {
            if (string.IsNullOrEmpty(id)) return BadRequest();

            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return NotFound();

            var result = await _userManager.DeleteAsync(user);
            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                    ModelState.AddModelError("", error.Description);
                return RedirectToAction(nameof(ManageUsers));
            }

            var adminRecord = await _context.Admins.FirstOrDefaultAsync(a => a.UserId == id);
            if (adminRecord != null)
            {
                _context.Admins.Remove(adminRecord);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(ManageUsers));
        }

        // -----------------------------
        // INCIDENT MANAGEMENT
        // -----------------------------
        [Authorize(Roles = "Admin")]
        public IActionResult ManageIncidents() =>
            View(_context.Disasters.OrderByDescending(i => i.DateReported).ToList());

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult SetIncidentStatus(int id, string status)
        {
            var incident = _context.Disasters.FirstOrDefault(i => i.Id == id);
            if (incident == null) return NotFound();
            incident.Status = status;
            _context.SaveChanges();
            return RedirectToAction(nameof(ManageIncidents));
        }

        // -----------------------------
        // DONATION MANAGEMENT
        // -----------------------------
        [Authorize(Roles = "Admin")]
        public IActionResult ManageDonations()
        {
            // Return Donation objects directly to the view
            var donations = _context.Donations
                                    .OrderByDescending(d => d.DateDonated)
                                    .ToList();
            return View(donations);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult SetDonationStatus(int id, string status)
        {
            var donation = _context.Donations.FirstOrDefault(d => d.DonationID == id);
            if (donation == null) return NotFound();
            donation.Status = status;
            _context.SaveChanges();
            return RedirectToAction(nameof(ManageDonations));
        }

        // -----------------------------
        // VOLUNTEER & TASK MANAGEMENT
        // -----------------------------
        [Authorize(Roles = "Admin")]
        public IActionResult ManageVolunteers() => View(_context.Volunteers.ToList());

        [Authorize(Roles = "Admin")]
        public IActionResult ManageTasks()
        {
            ViewBag.Volunteers = _context.Volunteers.ToList();
            return View(_context.VolunteerTasks.ToList());
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult AssignTask(int taskId, int volunteerId)
        {
            var task = _context.VolunteerTasks.FirstOrDefault(t => t.TaskID == taskId);
            if (task == null) return NotFound();

            task.VolunteerID = volunteerId;
            _context.SaveChanges();

            return RedirectToAction(nameof(ManageTasks));
        }
    }
}
