﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using GiftOfTheGivers_WebApp.Models;
using System.Linq;
using GiftOfTheGivers_WebApp.Data;

namespace GiftOfTheGivers_WebApp.Controllers
{
   
    public class DisastersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DisastersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Show list of disasters
        
        public IActionResult Index()
        {
            var disasters = _context.Disasters.ToList();
            return View(disasters);
        }

        [Authorize]
        // Report new disaster (GET)
        public IActionResult Report()
        {
            return View();
        }

        // Report new disaster (POST)
        [HttpPost]
        public IActionResult Create(Disaster incident)
        {
            if (ModelState.IsValid)
            {
                _context.Disasters.Add(incident);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(incident);
        }
    }
}
