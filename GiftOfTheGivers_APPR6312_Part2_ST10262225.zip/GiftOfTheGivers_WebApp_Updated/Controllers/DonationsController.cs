﻿using GiftOfTheGivers_WebApp.Data;
using GiftOfTheGivers_WebApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace GiftOfTheGivers_WebApp.Controllers
{
   
    public class DonationsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DonationsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Admin: View all donations
        public IActionResult Index()
        {
            var donations = _context.Donations.ToList();
            return View(donations);
        }

        // User: GET donation form
        [HttpGet]
        public IActionResult Donate()
        {
            return View(new DonationViewModel());
        }

        // User: POST donation form
        [HttpPost]
        public async Task<IActionResult> Donate(DonationViewModel model)
        {
            if (ModelState.IsValid)

            {
                // Map ViewModel to Donation entity
                var donation = new Donation
                {
                    ResourceType = model.ResourceType,
                    Quantity = model.Quantity,
                    DateDonated = DateTime.Now,
                    Status = "Pending",
                    Notes = model.Notes,
                    DeliveryOption = model.DeliveryOption,
                    PickupAddress = model.PickupAddress,
                    PickupDate = model.PickupDate,
                    PickupTime = model.PickupTime,
                  
                };


                if (model.ResourceType == "Funds")
                {
                    donation.Notes += $"\nBank: {model.BankName}, Account: {model.AccountNumber}, Holder: {model.AccountHolder}";
                }

                _context.Donations.Add(donation);
                _context.SaveChanges();

                return RedirectToAction("ThankYou");
            }

            return View(model);
        }

        // Thank You page
        public IActionResult ThankYou()
        {
            return View();
        }
    }
}
