﻿using GiftOfTheGivers_WebApp.Data;
using GiftOfTheGivers_WebApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GiftOfTheGivers_WebApp.Controllers
{
    
    public class VolunteersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VolunteersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // List all volunteers
        public IActionResult Index()
        {
            var volunteers = _context.Volunteers.ToList();
            return View(volunteers);
        }

        // GET: Register as a volunteer
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // POST: Handle volunteer registration
        [HttpPost]
        public IActionResult Register(Volunteer volunteer)
        {
            if (ModelState.IsValid)
            {
                _context.Volunteers.Add(volunteer);
                _context.SaveChanges();

                return RedirectToAction("ThankYou");
            }

            return View(volunteer);
        }

        // GET: Thank You page after registration
        public IActionResult ThankYou()
        {
            return View();
        }

        // GET: Assign tasks
        [HttpGet]
        public IActionResult AssignTask()
        {
            return View();
        }

        // POST: Assign tasks to volunteers
        [HttpPost]
        public IActionResult AssignTask(VolunteerTask task)
        {
            if (ModelState.IsValid)
            {
                _context.VolunteerTasks.Add(task);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(task);
        }
    }
}
